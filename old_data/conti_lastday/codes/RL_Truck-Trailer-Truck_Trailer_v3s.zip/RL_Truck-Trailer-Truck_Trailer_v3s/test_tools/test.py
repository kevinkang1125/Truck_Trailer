import numpy as np
index = np.random.randint(0,5)
print(index)