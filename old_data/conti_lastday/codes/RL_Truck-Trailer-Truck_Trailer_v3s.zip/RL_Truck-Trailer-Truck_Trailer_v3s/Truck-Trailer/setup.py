from gettext import install
from setuptools import setup

setup(
    name ="truck_trailer",
    version='0.1.1',
    install_requires = ['gym','pybullet','matplotlib']

)