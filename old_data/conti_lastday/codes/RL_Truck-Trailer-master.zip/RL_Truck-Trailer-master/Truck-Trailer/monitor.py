import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib import style

style.use('fivethirtyeight')

fig = plt.figure()
ax1 = fig.add_subplot(1,1,1)

def animate(i):
    graph_data = open('throttle.txt', 'r').read()
    lines = graph_data.split('\n')
    xs = []
    for line in lines:
        if len(line)>1:
            x = line
            xs.append((float(x)))
    ax1.clear()
    ax1.plot(xs)

ani = animation.FuncAnimation(fig,animate,interval=100)
plt.show()
