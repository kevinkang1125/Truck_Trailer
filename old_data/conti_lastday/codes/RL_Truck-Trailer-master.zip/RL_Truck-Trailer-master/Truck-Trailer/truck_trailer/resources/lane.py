from fileinput import filename
from http import client
from typing_extensions import Self
import pybullet as p
import os
import math
import scipy.interpolate as si
import numpy as np
from truck_trailer.resources.goal import Goal

class Lane:
    def __init__(self,client):
        self.client = client
        
        

    def generate_lane(self):
        points = np.array([[0, 0], [105, 60], [150, -60], [270, 90]])
        x = points[:,0]
        y = points[:,1]

        t = range(len(x))
        ipl_t = np.linspace(0.0, len(points) - 1, 100)

        x_tup = si.splrep(t, x, k=3)
        y_tup = si.splrep(t, y, k=3)
        x_i = si.splev(ipl_t, x_tup)
        y_i = si.splev(ipl_t, y_tup)
        planeId = p.loadURDF("./Truck-Trailer/truck_trailer/resources/simpleplane.urdf",
                            basePosition = [0,0,0],
                            physicsClientId = self.client)
        pointsId = {}
        goallist=[]
        for i in range(100):
            goal = (x_i[i],y_i[i])
            goallist.append(goal)
            pointsId[i]=Goal(self.client,goal)
             
        return goallist,pointsId,planeId